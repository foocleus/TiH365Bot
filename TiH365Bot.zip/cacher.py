import os

CACHE_PATH = "./cache"


def loadCachedText(date, language):
    try:
        with open(f"{CACHE_PATH}/{language}/{date}", "r") as cacheFile:
            return cacheFile.read()
    except:
        return False


def writeTextToCache(text, date, language):
    if not os.path.exists(CACHE_PATH):
        os.makedirs(CACHE_PATH)
    if not os.path.exists(f"{CACHE_PATH}/{language}"):
        os.makedirs(f"{CACHE_PATH}/{language}")

    with open(f"{CACHE_PATH}/{language}/{date}", "w") as cacheFile:
        cacheFile.write(text)
    
